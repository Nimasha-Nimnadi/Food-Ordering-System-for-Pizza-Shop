package patterns.command;

public interface Command {
    void execute();
}
